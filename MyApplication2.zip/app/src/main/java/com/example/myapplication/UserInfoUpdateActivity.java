package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.Toast;

public class UserInfoUpdateActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info_update);

        // SharedPreferences에서 로그인한 아이디 가져오기
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String loggedInUserId = sharedPreferences.getString("id", ""); // 아이디 가져오기


        // 아이디 필드에 로그인한 아이디 설정
        EditText userIdEditText = findViewById(R.id.etUserId);
        userIdEditText.setText(loggedInUserId);  // 아이디 입력란에 로그인한 아이디 표시
        userIdEditText.setEnabled(false);  // 수정 불가능하게 설정
        userIdEditText.setFocusable(false);  // 수정 불가능하게 설정
        userIdEditText.setClickable(false);  // 클릭할 수 없게 설정

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        //EditText etGender = findViewById(R.id.erGender);

        EditText etPhone = findViewById(R.id.etPhone);



        // 취소 버튼 연결
        Button btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 1번 화면으로 돌아가는 기능 (SettingsActivity로 이동)
                Intent intent = new Intent(UserInfoUpdateActivity.this, SettingsActivity.class);
                startActivity(intent);
                finish(); // 현재 Activity 종료
            }
        });
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // 확인 버튼에 다른 로직 추가 가능
        Button btnConfirm = findViewById(R.id.btnConfirm);
        btnConfirm.setOnClickListener(v -> {
            String password = etPassword.getText().toString().trim();
            String name = etName.getText().toString().trim();
            //String gender = etGender.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            // 빈 값 확인
            if ( password.isEmpty() || name.isEmpty() || /*gender.isEmpty() ||*/ phone.isEmpty() || email.isEmpty()) {
                Toast.makeText(UserInfoUpdateActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                editor.putString("password", password);
                editor.putString("name", name);
                //editor.putString("gender", gender);
                editor.putString("phone", phone);
                editor.putString("email", email);
                editor.apply();

                Toast.makeText(UserInfoUpdateActivity.this, "UserInfoUpdating successful!", Toast.LENGTH_SHORT).show();
                finish(); // RegisterActivity 종료
            }
        });

    }
}
