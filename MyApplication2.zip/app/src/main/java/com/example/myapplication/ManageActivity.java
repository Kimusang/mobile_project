package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ManageActivity extends AppCompatActivity {

    private static final int REQUEST_GALLERY = 1;
    private static final String SERVER_URL = "http://192.168.0.3:5000/predict";
    private TextView textView;
    private ViewPager2 imageViewPager;
    private ImagePagerAdapter imagePagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage);

        textView = findViewById(R.id.textView);
        imageViewPager = findViewById(R.id.imageViewPager);
        imagePagerAdapter = new ImagePagerAdapter(this, new ArrayList<>());
        imageViewPager.setAdapter(imagePagerAdapter);

        Button albumButton = findViewById(R.id.albumButton);
        albumButton.setOnClickListener(view -> {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, REQUEST_GALLERY);
        });

        Button identifyButton = findViewById(R.id.identifyButton);
        identifyButton.setOnClickListener(view -> {
            Intent intent = new Intent(ManageActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        Button manageButton = findViewById(R.id.manageButton);
        manageButton.setOnClickListener(view -> {
            Toast.makeText(this, "이미 관리 화면입니다.", Toast.LENGTH_SHORT).show();
        });

        Button graphButton = findViewById(R.id.graphButton);
        graphButton.setOnClickListener(v -> {
            Intent intent = new Intent(ManageActivity.this, Manage2Activity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUEST_GALLERY && data != null) {
            Uri selectedImageUri = data.getData();
            uploadImageToServer(selectedImageUri);
        }
    }

    private void uploadImageToServer(Uri imageUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
            byte[] imageData = byteArrayOutputStream.toByteArray();

            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build();

            RequestBody fileBody = RequestBody.create(MediaType.parse("image/jpeg"), imageData);
            MultipartBody.Part filePart = MultipartBody.Part.createFormData("file", "upload.jpg", fileBody);

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addPart(filePart)
                    .build();

            Request request = new Request.Builder()
                    .url(SERVER_URL)
                    .post(requestBody)
                    .build();

            new Thread(() -> {
                try {
                    Response response = client.newCall(request).execute();
                    if (response.isSuccessful()) {
                        String jsonResponse = response.body().string();
                        handleServerResponse(jsonResponse, bitmap);
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "서버 응답 실패", Toast.LENGTH_SHORT).show());
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "오류 발생", Toast.LENGTH_SHORT).show());
                    Log.e("Upload Error", e.toString());
                }
            }).start();

        } catch (Exception e) {
            Toast.makeText(this, "이미지 업로드 실패", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleServerResponse(String jsonResponse, Bitmap originalBitmap) {
        runOnUiThread(() -> {
            try {
                JSONObject json = new JSONObject(jsonResponse);
                JSONObject inclusionResult = json.optJSONObject("inclusion_result");
                if (inclusionResult != null) {
                    JSONArray results = inclusionResult.optJSONArray("results");

                    if (results != null && results.length() > 0) {
                        StringBuilder resultText = new StringBuilder("결과:\n");
                        for (int i = 0; i < results.length(); i++) {
                            resultText.append(results.getString(i)).append("\n");
                        }
                        textView.setText(resultText.toString());
                    } else {
                        textView.setText("결과를 찾을 수 없습니다.");
                    }
                } else {
                    textView.setText("응답 오류");
                }
                JSONArray images = json.optJSONArray("images");
                List<Bitmap> imageList = new ArrayList<>();
                imageList.add(originalBitmap);

                if (images != null) {
                    for (int i = 0; i < images.length(); i++) {
                        String imageUrl = images.getString(i);
                        Bitmap bitmap = BitmapFactory.decodeStream(new java.net.URL(imageUrl).openStream());
                        imageList.add(bitmap);
                    }
                }
                imagePagerAdapter.updateImages(imageList);

            } catch (Exception e) {
                Toast.makeText(this, "결과 처리 오류", Toast.LENGTH_SHORT).show();
                Log.e("Response Error", e.toString());
            }
        });
    }
}