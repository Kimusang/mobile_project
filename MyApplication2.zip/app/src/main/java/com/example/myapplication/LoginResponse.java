package com.example.myapplication;

public class LoginResponse {
    private boolean success;
    private String message;
    private String user_name;

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getUserName() {
        return user_name;
    }
}