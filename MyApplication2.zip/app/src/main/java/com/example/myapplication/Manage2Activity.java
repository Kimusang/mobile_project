package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import org.json.JSONObject;

import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.json.JSONObject;
public class Manage2Activity extends AppCompatActivity {

    private ApiService apiService; // Retrofit API 서비스

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage2);

        // Intent에서 선택된 사진 데이터 가져오기
        ImageView selectedImageView = findViewById(R.id.selectedImageView);
        Intent intent = getIntent();
        Bitmap selectedImage = intent.getParcelableExtra("selectedImage");
        if (selectedImage != null) {
            selectedImageView.setImageBitmap(selectedImage);
        }

        // Retrofit 초기화
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.0.3:5000/") // Flask 서버 주소
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        apiService = retrofit.create(ApiService.class);

        // EditText 및 버튼 참조
        EditText toothNumberInput = findViewById(R.id.toothNumberInput);
        Button confirmButton = findViewById(R.id.confirmButton);

        // 버튼 클릭 리스너
        confirmButton.setOnClickListener(v -> {
            String toothNumber = toothNumberInput.getText().toString().trim();
            if (toothNumber.isEmpty()) {
                Toast.makeText(Manage2Activity.this, "이빨 번호를 입력하세요", Toast.LENGTH_SHORT).show();
            } else {
                // 그래프 데이터 요청
                fetchGraphImage(toothNumber);
            }
        });
    }

    private void fetchGraphImage(String toothNumber) {
        // JSON 데이터 생성
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("tooth_number", toothNumber);  // JSON 객체에 tooth_number 추가
        } catch (Exception e) {
            e.printStackTrace();
        }

        // RequestBody로 변환
        RequestBody requestBody = RequestBody.create(
                MediaType.parse("application/json"), jsonObject.toString()
        );

        // POST 요청 수행
        apiService.getGraph(requestBody).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // 이미지를 Bitmap으로 변환하여 ImageView에 표시
                    try {
                        InputStream inputStream = response.body().byteStream();
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                        ImageView graphImageView = findViewById(R.id.graph_image);
                        graphImageView.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(Manage2Activity.this, "이미지 처리 실패", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(Manage2Activity.this, "서버 응답 실패", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(Manage2Activity.this, "네트워크 오류: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}