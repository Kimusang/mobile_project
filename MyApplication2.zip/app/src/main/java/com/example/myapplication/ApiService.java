package com.example.myapplication;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Field;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.http.Part;
import java.util.List;
import java.util.Map;

import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    @Multipart
    @POST("/upload")
    Call<ResponseBody> uploadFile(@Part MultipartBody.Part file);
    @POST("/register")
    Call<RegisterResponse> register(@Body RegisterRequest request);
    @POST("/login")
    Call<LoginResponse> login(@Body LoginRequest request);

    @Multipart
    @POST("/predict")
    Call<ResponseBody> predict(@Part MultipartBody.Part file);

    @GET("/generate-graph")
    Call<ResponseBody> getGraph();

    @POST("/graph")
    Call<ResponseBody> getGraph(@Body RequestBody body);

    @GET("graph_image")
    Call<ResponseBody> getGraphImage(@Query("image_path") String imagePath);
}