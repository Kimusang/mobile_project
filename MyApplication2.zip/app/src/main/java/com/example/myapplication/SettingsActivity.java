package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.ApiService;
import com.example.myapplication.RetrofitClient;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingsActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA = 1;
    private static final int REQUEST_GALLERY = 2;
    private ApiService apiService;
    private static final int REQUEST_PICK_FILE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Button settingsButton = findViewById(R.id.settingsButton);
        Button cameraButton = findViewById(R.id.cameraButton);
        Button albumButton = findViewById(R.id.albumButton);
        Button identifyButton = findViewById(R.id.identifyButton);
        Button manageButton = findViewById(R.id.manageButton);

        // 설정 버튼 클릭 시 팝업 메뉴 표시
        settingsButton.setOnClickListener(this::showPopupMenu);

        // 카메라 버튼 클릭 시 카메라 실행
        cameraButton.setOnClickListener(view -> {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(cameraIntent, REQUEST_CAMERA);
            }
        });

        // 앨범 버튼 클릭 시 앨범 실행
        albumButton.setOnClickListener(view -> {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, REQUEST_GALLERY);
        });

        // 감별 버튼 클릭 시 동작 구현
        identifyButton.setOnClickListener(view -> {
            Toast.makeText(this, "감별 기능을 구현합니다.", Toast.LENGTH_SHORT).show();
        });

        // 관리 버튼 클릭 시 관리 화면으로 이동
        manageButton.setOnClickListener(view -> {
            Intent intent = new Intent(SettingsActivity.this, ManageActivity.class);
            startActivity(intent);
        });

        //파일 선택(업로드)
        // Retrofit API 서비스 초기화

        apiService = RetrofitClient.getClient().create(ApiService.class);

        // 파일 선택 버튼 클릭 리스너
        Button selectFileButton = findViewById(R.id.selectFileButton);
        selectFileButton.setOnClickListener(v -> {
            // 파일 선택 인텐트 실행
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*"); // 모든 파일 유형 선택 가능
            startActivityForResult(intent, REQUEST_PICK_FILE);
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_PICK_FILE && resultCode == RESULT_OK && data != null) {
            Uri fileUri = data.getData();
            String filePath = FileUtils.getPath(this, fileUri); // Uri를 절대 경로로 변환 (FileUtils는 직접 구현 필요)

            if (filePath != null) {
                uploadFile(filePath); // 파일 업로드 메서드 호출
            } else {
                Toast.makeText(this, "파일 경로를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void uploadFile(String filePath) {
        File file = new File(filePath);
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(), requestFile);

        apiService.uploadFile(body).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(SettingsActivity.this, "파일 업로드 성공", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SettingsActivity.this, "파일 업로드 실패", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(SettingsActivity.this, "네트워크 오류: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 카메라 및 앨범 결과 처리
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (resultCode == RESULT_OK) {
//            if (requestCode == REQUEST_CAMERA) {
//                Toast.makeText(this, "사진이 성공적으로 촬영되었습니다.", Toast.LENGTH_SHORT).show();
//            } else if (requestCode == REQUEST_GALLERY) {
//                Toast.makeText(this, "이미지가 성공적으로 선택되었습니다.", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }


    // 설정 버튼의 팝업 메뉴 표시
    private void showPopupMenu(View anchorView) {
        // 팝업 창을 inflate
        View popupView = getLayoutInflater().inflate(R.layout.popup_menu, null);
        PopupWindow popupWindow = new PopupWindow(popupView,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                true);

        popupWindow.showAsDropDown(anchorView);

        // 팝업 내부 버튼 설정
        Button btnUpdateProfile = popupView.findViewById(R.id.btnUpdateProfile);
        btnUpdateProfile.setOnClickListener(v -> {
            popupWindow.dismiss();
            Intent intent = new Intent(SettingsActivity.this, UserInfoUpdateActivity.class);
            startActivity(intent);
            Toast.makeText(this, "회원정보 수정 화면으로 이동합니다.", Toast.LENGTH_SHORT).show();
        });

        Button btnSettings = popupView.findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(v -> {
            popupWindow.dismiss();
            Toast.makeText(this, "설정 화면으로 이동합니다.", Toast.LENGTH_SHORT).show();
        });
    }
}
