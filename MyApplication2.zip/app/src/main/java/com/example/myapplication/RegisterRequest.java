package com.example.myapplication;  // 모델 클래스가 위치한 패키지

public class RegisterRequest {
    private String user_id;
    private String password;
    private String name;
    private boolean gender;
    private String phone;
    private String email;

    // 생성자
    public RegisterRequest(String userId, String password, String name, boolean gender, String phone, String email) {
        this.user_id = userId;
        this.password = password;
        this.name = name;
        this.gender = gender;
        this.phone = phone;
        this.email = email;
    }

    // Getter와 Setter
    public String getUserId() {
        return user_id;
    }

    public void setUserId(String userId) {
        this.user_id = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
