package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import java.util.ArrayList;

public class LineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linechart); // XML 파일 연결

        // LineChart 연결
        LineChart lineChart = findViewById(R.id.lineChart);

        // 데이터 생성 (x축: 날짜, y축: 충치 확률)
        ArrayList<Entry> entries = new ArrayList<>();
        entries.add(new Entry(1, 10)); // 1일: 충치 확률 10%
        entries.add(new Entry(2, 20)); // 2일: 충치 확률 20%
        entries.add(new Entry(3, 15)); // 3일: 충치 확률 15%
        entries.add(new Entry(4, 25)); // 4일: 충치 확률 25%
        entries.add(new Entry(5, 30)); // 5일: 충치 확률 30%

        // 데이터셋 생성
        LineDataSet dataSet = new LineDataSet(entries, "충치 확률");
        dataSet.setColor(Color.WHITE); // 선 색상
        dataSet.setValueTextColor(Color.BLACK); // 값 텍스트 색상
        dataSet.setLineWidth(2f); // 선 두께
        dataSet.setCircleColor(Color.WHITE); // 데이터 점 색상
        dataSet.setCircleRadius(5f); // 데이터 점 크기
        dataSet.setDrawValues(true); // 데이터 값 표시

        // 데이터 설정
        LineData lineData = new LineData(dataSet);
        lineChart.setData(lineData);

        // Chart 설정
        lineChart.setBackgroundColor(Color.parseColor("#E8D3F8")); // 배경색
        lineChart.getDescription().setText(""); // 설명 제거

        // X축 설정
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextColor(Color.BLACK);
        xAxis.setDrawGridLines(false); // 격자선 제거
        xAxis.setGranularity(1f); // x축 간격
        xAxis.setLabelCount(5, true); // 라벨 개수

        // Y축 설정 (왼쪽)
        YAxis leftAxis = lineChart.getAxisLeft();
        leftAxis.setTextColor(Color.BLACK);
        leftAxis.setAxisMinimum(0f); // 최소값
        leftAxis.setAxisMaximum(100f); // 최대값
        leftAxis.setDrawGridLines(true); // 격자선 표시

        // 오른쪽 Y축 비활성화
        YAxis rightAxis = lineChart.getAxisRight();
        rightAxis.setEnabled(false);

        // 그래프 새로고침
        lineChart.invalidate();
    }
}
